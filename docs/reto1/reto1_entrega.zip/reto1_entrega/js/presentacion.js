
const sl=[...document.querySelectorAll('.slide')],notas=document.getElementById('notas'),prog=document.querySelector('#prog i');
const SO_QUIETO=matchMedia('(prefers-reduced-motion: reduce)').matches;
let eleccion=null;try{eleccion=localStorage.getItem('reto1_mov')}catch(e){}
const pedido=new URLSearchParams(location.search).get('movimiento');
if(pedido==='1'||pedido==='0'){eleccion=pedido==='1'?'on':'off';try{localStorage.setItem('reto1_mov',eleccion)}catch(e){}}
let quieto=eleccion?eleccion==='off':SO_QUIETO;
document.documentElement.dataset.mov=quieto?'off':'on';
let i=-1,tok=0,salida=null;
const SEL='h1,h2,.badge,.logo,.sub,.pie,.lead,.nota,.banda,.card,.fila,.num.xl,.split>img,img.ancho,.barras>*,#quiz';
sl.forEach(s=>{const c=[...s.querySelectorAll(SEL)];
 c.filter(a=>!c.some(o=>o!==a&&o.contains(a))).forEach((el,k)=>{el.classList.add('rev');
  const st=el.style,p=el.parentElement,hijo=[...p.children].indexOf(el);let dx=0,dy=36,sc=1;
  if(/^H[12]$/.test(el.tagName)){dx=-80;dy=0}
  else if(el.matches('.sub,.lead')){dx=-50;dy=12}
  else if(el.tagName==='IMG'){sc=.9;dy=34}
  else if(p.classList.contains('grid')){const n=+(/c(\d)/.exec(p.className)||[0,3])[1];dx=(hijo%n-(n-1)/2)*80;dy=50}
  else if(el.closest('.pasos,.ocho')){dx=-60;dy=0}
  else if(p.classList.contains('barras')){dx=hijo%3===2?0:-50;dy=0}
  st.setProperty('--i',p.classList.contains('barras')?Math.floor(hijo/3):Math.min(k,12));
  st.setProperty('--dx',dx+'px');st.setProperty('--dy',dy+'px');st.setProperty('--sc',sc)})});
const CIFRA=/^([−-]?)(\d{1,3}(?:\.\d{3})+|\d+)(?:,(\d+))?(\s*(?:%|€|M€))?$/;
const fmtN=(x,dec)=>{const[a,b]=Math.abs(x).toFixed(dec).split('.');return (x<0?'−':'')+a.replace(/\B(?=(\d{3})+(?!\d))/g,'.')+(b?','+b:'')};
function contar(el,t){
 if(el.closest('.panel'))return;
 const f=el.dataset.final||(el.dataset.final=el.textContent.trim()),m=f.match(CIFRA);el.textContent=f;
 if(!m||quieto)return;
 const dec=(m[3]||'').length,val=parseFloat(m[2].replace(/\./g,'')+(dec?'.'+m[3]:'')),suf=m[4]||'';
 const r=el.closest('.rev'),ini=performance.now()+250+85*(r?parseInt(r.style.getPropertyValue('--i'))||0:0)+150;
 el.textContent=fmtN(0,dec)+suf;
 const paso=now=>{if(t!==tok){el.textContent=f;return}
  const p=Math.min(1,Math.max(0,(now-ini)/1300));{const v=fmtN(val*(1-Math.pow(1-p,3)),dec);el.textContent=p<1?(/[1-9]/.test(v)?m[1]:'')+v+suf:f}
  if(p<1)requestAnimationFrame(paso)};
 requestAnimationFrame(paso)}
const restaura=v=>v.querySelectorAll('.num[data-final]').forEach(e=>e.textContent=e.dataset.final);
const mmss=s=>{s=Math.round(Math.abs(s));return Math.floor(s/60)+':'+String(s%60).padStart(2,'0')};
const TOTAL=sl.reduce((a,x)=>a+parseFloat(x.dataset.min),0);
function pinta(){const s=sl[i],cab=document.createElement('span');cab.className='cab';
 cab.textContent=`Diapositiva ${i+1} de ${sl.length} · ${s.dataset.min} min · acumulado ${mmss(s.dataset.acum*60)} de ${mmss(TOTAL*60)}`;
 notas.replaceChildren(cab,document.createTextNode(s.dataset.notas));notas.scrollTop=0}
const reloj=document.getElementById('reloj');let t0=0,acum=0,corre=false;
function tic(){const t=acum+(corre?(performance.now()-t0)/1000:0),fin=parseFloat(sl[i].dataset.acum)*60,ini=fin-parseFloat(sl[i].dataset.min)*60,
 d=t<ini?t-ini:t>fin?t-fin:0;
 reloj.textContent=`${mmss(t)} / ${mmss(TOTAL*60)} · diapositiva ${i+1}: ${mmss(ini)}–${mmss(fin)} · ${d===0?'en hora':mmss(d)+(d>0?' de retraso':' de adelanto')}`}
setInterval(tic,500);
function fit(){const k=Math.min(innerWidth/1280,innerHeight/720);sl.forEach(s=>s.style.transform=`scale(${k})`)}
function ver(n){n=Math.max(0,Math.min(sl.length-1,n));if(n===i)return;
 document.body.dataset.dir=n<i?'atras':'adelante';
 if(i>=0){const v=sl[i];restaura(v);v.classList.remove('on');
  if(!quieto){v.classList.add('sale');clearTimeout(salida);salida=setTimeout(()=>sl.forEach(s=>s.classList.remove('sale')),650)}}
 i=n;sl[i].classList.remove('sale');sl[i].classList.add('on');
 prog.style.transform=`scaleX(${(i+1)/sl.length})`;
 pinta();try{history.replaceState(null,'','#'+(i+1))}catch(e){}
 const t=++tok;sl[i].querySelectorAll('.num').forEach(el=>contar(el,t));
 if(sl[i].classList.contains('quiz'))quizInicio()}
const toast=document.getElementById('toast');let tt=null;
function aviso(t,ms){toast.textContent=t;toast.classList.add('on');clearTimeout(tt);tt=setTimeout(()=>toast.classList.remove('on'),ms||2200)}
function alterna(){quieto=!quieto;document.documentElement.dataset.mov=quieto?'off':'on';
 try{localStorage.setItem('reto1_mov',quieto?'off':'on')}catch(e){}
 aviso(quieto?'Movimiento desactivado':'Movimiento activado');
 const s=sl[i];s.classList.remove('on','sale');void s.offsetWidth;s.classList.add('on');
 const t=++tok;s.querySelectorAll('.num').forEach(el=>contar(el,t))}
addEventListener('beforeprint',()=>{tok++;sl.forEach(restaura)});
// Dentro de un laboratorio o del cuestionario, el teclado y el ratón son suyos: las flechas mueven los deslizadores, no las diapositivas.
const interactivo=el=>el&&el.closest&&el.closest('#quiz,input,button');
addEventListener('keydown',ev=>{if(interactivo(ev.target)&&['ArrowRight','ArrowLeft',' '].includes(ev.key))return;
 if(['ArrowRight','PageDown',' '].includes(ev.key)){ev.preventDefault();ver(i+1)}
 else if(['ArrowLeft','PageUp'].includes(ev.key))ver(i-1);else if(ev.key==='Home')ver(0);else if(ev.key==='End')ver(sl.length-1);
 else if(ev.key==='n'||ev.key==='N')notas.classList.toggle('on');
 else if(ev.key==='m'||ev.key==='M')alterna();
 else if(ev.key==='T'){acum=0;t0=performance.now();tic()}
 else if(ev.key==='t'){if(corre){acum+=(performance.now()-t0)/1000;corre=false}else{t0=performance.now();corre=true;reloj.classList.add('on')}tic()}
 else if(ev.key==='f'||ev.key==='F'){document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen()}});
document.getElementById('deck').addEventListener('click',ev=>{if(interactivo(ev.target))return;ver(ev.clientX>innerWidth/3?i+1:i-1)});
let x0=null;addEventListener('touchstart',e=>{x0=interactivo(e.target)?null:e.touches[0].clientX});addEventListener('touchend',e=>{if(x0===null)return;const d=e.changedTouches[0].clientX-x0;if(Math.abs(d)>40)ver(d<0?i+1:i-1);x0=null});

/* ---------- Cuestionario ---------- */
const PREG=[
 {q:'¿Qué parte de las ventas de Burglar King se va en personal?',o:['16 %','28 %','33 %','45 %'],ok:2,
  x:'<b>33 %</b>: 14.800 € de 45.000 €. Dentro de la banda del 30-35 % habitual en el servicio en mesa. El producto se lleva otro 32 %.'},
 {q:'Burglar King es una sociedad limitada. ¿Desde cuándo debe tener su facturación adaptada a Verifactu?',o:['1 de enero de 2026','1 de enero de 2027','1 de julio de 2027','No le afecta: es una microempresa'],ok:1,
  x:'<b>1 de enero de 2027</b> para las sociedades (1 de julio de 2027 para el resto), tras el aplazamiento del Real Decreto-ley 15/2025. Su TPV de 2016 no se va a adaptar.'},
 {q:'Según el estudio de TheFork (2026), ¿qué hace que más españoles descarten un restaurante?',o:['El precio','La ubicación','No poder reservar en línea','Una mala reseña en internet'],ok:3,
  x:'<b>Una mala reseña</b>, para el 62 %; el precio solo para el 24 %. Por eso la prioridad del marketing es el perfil de Google, que cuesta 0 €.'}];
let qi=0,qp=0;const Q=document.getElementById('quiz');
function quizInicio(){qi=0;qp=0;quizPinta()}
function quizPinta(){if(qi>=PREG.length){quizFin();return}
 const p=PREG[qi];Q.innerHTML=`<div class="qn">Pregunta ${qi+1} de ${PREG.length} · aciertos: ${qp}</div><div class="q">${p.q}</div>
  <div class="ops">${p.o.map((o,k)=>`<button data-k="${k}">${String.fromCharCode(65+k)}. ${o}</button>`).join('')}</div><div class="fb"></div><div class="qbar"><span class="pts"></span></div>`;
 Q.querySelectorAll('.ops button').forEach(b=>b.addEventListener('click',()=>{const k=+b.dataset.k,ok=k===p.ok;if(ok)qp++;
  Q.querySelectorAll('.ops button').forEach(x=>{x.disabled=true;if(+x.dataset.k===p.ok)x.classList.add('ok')});if(!ok)b.classList.add('ko');
  Q.querySelector('.fb').innerHTML=(ok?'✔ Correcto. ':'✘ No. ')+p.x;
  const sig=document.createElement('button');sig.textContent=qi<PREG.length-1?'Siguiente pregunta →':'Ver resultado';sig.addEventListener('click',()=>{qi++;quizPinta()});
  Q.querySelector('.qbar').append(sig)}))}
function quizFin(){const msg=qp===3?'¡Pleno! Habéis escuchado de verdad.':qp===2?'Muy bien: solo una se ha escapado.':qp===1?'Una de tres: el informe tiene las respuestas.':'Ninguna… toca releer el informe.';
 Q.innerHTML=`<div class="final"><div class="qn">Resultado</div><b class="num">${qp} / 3</b><p>${msg}</p><button class="otra">Repetir el cuestionario</button></div>`;
 Q.querySelector('.otra').addEventListener('click',quizInicio);
 if(!quieto&&qp>=2){const c=document.createElement('div');c.className='conf';for(let k=0;k<80;k++){const i=document.createElement('i');i.style.left=Math.random()*100+'%';i.style.background=['#e67e22','#27ae60','#f1c40f','#3498db'][k%4];i.style.animationDelay=Math.random()*1.2+'s';i.style.animationDuration=(2+Math.random()*1.5)+'s';c.append(i)}
  sl[i].append(c);setTimeout(()=>c.remove(),4500)}}

addEventListener('resize',fit);fit();ver((parseInt(location.hash.slice(1))||1)-1);
if(SO_QUIETO&&!eleccion)aviso('Tu sistema tiene las animaciones desactivadas. Pulsa M para activar el movimiento.',9000);
